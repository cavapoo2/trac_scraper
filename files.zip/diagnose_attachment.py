import asyncio
from playwright.async_api import async_playwright


async def diagnose_attachment_page(attachment_url: str):
    """
    Diagnostic script to inspect a Trac attachment page and find download links.
    """
    async with async_playwright() as p:
        browser = await p.chromium.launch(
            headless=False,
            args=['--disable-blink-features=AutomationControlled']
        )
        
        context = await browser.new_context(
            viewport={'width': 1920, 'height': 1080},
            user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36'
        )
        
        page = await context.new_page()
        page.set_default_timeout(60000)
        
        print(f"Loading attachment page: {attachment_url}")
        await page.goto(attachment_url, wait_until="domcontentloaded", timeout=60000)
        await page.wait_for_timeout(2000)
        
        print("\n" + "="*80)
        print("ATTACHMENT PAGE ANALYSIS")
        print("="*80)
        
        # Check page title
        print("\n1. Page Title:")
        title = await page.title()
        print(f"   {title}")
        
        # Find all links on the page
        print("\n2. All Links on Page:")
        all_links = await page.locator("a").all()
        print(f"   Total links found: {len(all_links)}")
        
        base_url = '/'.join(attachment_url.split('/')[:3])
        
        for i, link in enumerate(all_links[:20]):  # First 20 only
            try:
                text = await link.text_content()
                href = await link.get_attribute("href")
                if href:
                    # Make absolute URL
                    if href.startswith('/'):
                        full_href = base_url + href
                    else:
                        full_href = href
                    
                    print(f"   Link {i+1}: '{text.strip()[:50]}' -> {full_href}")
            except:
                pass
        
        # Look for specific download patterns
        print("\n3. Looking for Download Links:")
        
        patterns = [
            ("a[href*='raw-attachment']", "raw-attachment in URL"),
            ("a[href*='format=raw']", "format=raw parameter"),
            ("a:has-text('Download')", "Text contains 'Download'"),
            ("a:has-text('Original Format')", "Text contains 'Original Format'"),
            ("a:has-text('download')", "Text contains 'download' (lowercase)"),
            (".attachment a", "Links inside .attachment class"),
            ("#content .attachment a", "Links inside #content .attachment"),
        ]
        
        for selector, description in patterns:
            try:
                matches = await page.locator(selector).all()
                if matches:
                    print(f"\n   Pattern: {description}")
                    print(f"   Selector: {selector}")
                    print(f"   Matches: {len(matches)}")
                    for match in matches:
                        text = await match.text_content()
                        href = await match.get_attribute("href")
                        print(f"     - Text: '{text.strip()[:50]}'")
                        print(f"       URL: {href}")
            except:
                pass
        
        # Check the HTML structure
        print("\n4. Page Structure:")
        try:
            # Look for attachment info container
            containers = ["#content", ".attachment", "#attachments", "div.content"]
            for container in containers:
                count = await page.locator(container).count()
                if count > 0:
                    print(f"   {container}: {count} element(s)")
        except:
            pass
        
        # Extract filename from URL
        print("\n5. Filename Detection:")
        import re
        # Extract filename from URL patterns like:
        # /attachment/ticket/10735/filename.txt
        # /raw-attachment/ticket/10735/filename.txt
        filename_match = re.search(r'/([^/]+)$', attachment_url)
        if filename_match:
            filename = filename_match.group(1)
            # Remove query parameters
            filename = filename.split('?')[0]
            print(f"   Detected filename: {filename}")
            
            # Suggest download URLs
            print("\n6. Suggested Download URLs:")
            print(f"   Option 1 (format=raw): {attachment_url}?format=raw")
            
            # Try to construct raw-attachment URL
            if '/attachment/ticket/' in attachment_url:
                raw_url = attachment_url.replace('/attachment/ticket/', '/raw-attachment/ticket/')
                print(f"   Option 2 (raw-attachment): {raw_url}")
        
        # Save page HTML
        print("\n7. Saving Page Data:")
        html = await page.content()
        with open("attachment_page_debug.html", "w", encoding="utf-8") as f:
            f.write(html)
        print("   HTML saved to: attachment_page_debug.html")
        
        # Take screenshot
        await page.screenshot(path="attachment_page_debug.png")
        print("   Screenshot saved to: attachment_page_debug.png")
        
        print("\n" + "="*80)
        print("ANALYSIS COMPLETE")
        print("="*80)
        print("\nPress Enter to close browser...")
        
        input()
        await browser.close()


async def main():
    print("Trac Attachment Page Diagnostic Tool")
    print("="*80)
    print()
    print("Enter the URL of a Trac attachment page.")
    print("Example: https://trac.ffmpeg.org/attachment/ticket/10735/file.txt")
    print()
    
    attachment_url = input("Attachment page URL: ").strip()
    
    if not attachment_url:
        print("Error: No URL provided")
        return
    
    await diagnose_attachment_page(attachment_url)


if __name__ == "__main__":
    asyncio.run(main())
