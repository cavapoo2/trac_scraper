import asyncio
from playwright.async_api import async_playwright


async def diagnose_ticket_fields(ticket_url: str):
    """
    Diagnostic script to inspect Trac ticket properties/fields table.
    """
    async with async_playwright() as p:
        browser = await p.chromium.launch(
            headless=False,
            args=['--disable-blink-features=AutomationControlled']
        )
        
        context = await browser.new_context(
            viewport={'width': 1920, 'height': 1080},
            user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36'
        )
        
        page = await context.new_page()
        page.set_default_timeout(60000)
        
        print(f"Loading ticket: {ticket_url}")
        await page.goto(ticket_url, wait_until="domcontentloaded", timeout=60000)
        await page.wait_for_timeout(2000)
        
        print("\n" + "="*80)
        print("TICKET FIELDS/PROPERTIES ANALYSIS")
        print("="*80)
        
        # Check if properties section exists
        print("\n1. Properties Section:")
        properties_exists = await page.locator("#properties").count()
        print(f"   #properties element exists: {properties_exists > 0}")
        
        if properties_exists > 0:
            # Get the HTML structure
            properties_html = await page.locator("#properties").inner_html()
            print(f"   Properties HTML length: {len(properties_html)} chars")
            
            # Save it for inspection
            with open("properties_debug.html", "w", encoding="utf-8") as f:
                f.write(f"<div id='properties'>\n{properties_html}\n</div>")
            print("   Saved to: properties_debug.html")
        
        # Check for table structure
        print("\n2. Table Structure:")
        table_selectors = [
            "#properties table",
            "#properties table.properties",
            "table.properties"
        ]
        
        for selector in table_selectors:
            count = await page.locator(selector).count()
            print(f"   {selector}: {count} element(s)")
        
        # Analyze table rows
        print("\n3. Table Rows Analysis:")
        row_selectors = [
            "#properties table.properties tr",
            "#properties table tr",
            "#properties tr"
        ]
        
        for selector in row_selectors:
            rows = await page.locator(selector).all()
            if rows:
                print(f"\n   Using selector: {selector}")
                print(f"   Total rows: {len(rows)}")
                
                for i, row in enumerate(rows):
                    print(f"\n   Row {i+1}:")
                    
                    # Get row HTML
                    try:
                        row_html = await row.inner_html()
                        print(f"     HTML preview: {row_html[:150]}...")
                    except:
                        pass
                    
                    # Count th and td elements
                    th_count = await row.locator("th").count()
                    td_count = await row.locator("td").count()
                    print(f"     <th> elements: {th_count}")
                    print(f"     <td> elements: {td_count}")
                    
                    # Get all th elements
                    if th_count > 0:
                        ths = await row.locator("th").all()
                        print(f"     Headers:")
                        for j, th in enumerate(ths):
                            text = await th.text_content()
                            print(f"       th[{j}]: '{text.strip()}'")
                    
                    # Get all td elements
                    if td_count > 0:
                        tds = await row.locator("td").all()
                        print(f"     Values:")
                        for j, td in enumerate(tds):
                            text = await td.text_content()
                            # Truncate long values
                            display_text = text.strip()[:100]
                            if len(text.strip()) > 100:
                                display_text += "..."
                            print(f"       td[{j}]: '{display_text}'")
                
                # Only show first selector that has results
                break
        
        # Extract all fields as the scraper would
        print("\n4. Extracted Fields (as scraper would capture):")
        fields = {}
        
        try:
            property_rows = await page.locator("#properties table tr").all()
            
            for row in property_rows:
                headers = await row.locator("th").all()
                values = await row.locator("td").all()
                
                for i in range(min(len(headers), len(values))):
                    try:
                        header_text = await headers[i].text_content()
                        value_text = await values[i].text_content()
                        
                        if header_text and value_text:
                            header_clean = header_text.strip().rstrip(':').lower()
                            value_clean = value_text.strip()
                            
                            if header_clean and value_clean:
                                fields[header_clean] = value_clean
                    except:
                        continue
            
            print(f"\n   Total fields extracted: {len(fields)}")
            for field_name, field_value in fields.items():
                # Truncate long values for display
                display_value = field_value[:80]
                if len(field_value) > 80:
                    display_value += "..."
                print(f"   {field_name}: {display_value}")
        except Exception as e:
            print(f"   Error during extraction: {e}")
        
        # Look for fields by class name
        print("\n5. Looking for Fields by CSS Class:")
        field_classes = [
            "trac-field-reporter",
            "trac-field-owner", 
            "trac-field-status",
            "trac-field-priority",
            "trac-field-component",
            "trac-field-version",
            "trac-field-milestone",
            "trac-field-keywords",
            "trac-field-cc",
            "trac-field-type",
            "trac-field-severity",
            "trac-field-resolution"
        ]
        
        for class_name in field_classes:
            try:
                elem = await page.locator(f".{class_name}").first.text_content(timeout=1000)
                if elem:
                    print(f"   .{class_name}: '{elem.strip()}'")
            except:
                pass
        
        # Take screenshot of the properties section
        print("\n6. Taking Screenshot:")
        try:
            properties_elem = page.locator("#properties")
            await properties_elem.screenshot(path="properties_screenshot.png")
            print("   Properties section saved to: properties_screenshot.png")
        except:
            await page.screenshot(path="full_page_screenshot.png")
            print("   Full page saved to: full_page_screenshot.png")
        
        print("\n" + "="*80)
        print("ANALYSIS COMPLETE")
        print("="*80)
        print("\nFiles saved:")
        print("  - properties_debug.html (HTML of properties section)")
        print("  - properties_screenshot.png (screenshot)")
        print("\nPress Enter to close browser...")
        
        input()
        await browser.close()


async def main():
    print("Trac Ticket Fields Diagnostic Tool")
    print("="*80)
    print()
    
    ticket_url = input("Enter Trac ticket URL (or press Enter for default): ").strip()
    if not ticket_url:
        ticket_url = "https://trac.ffmpeg.org/ticket/10735"
        print(f"Using default: {ticket_url}")
    
    await diagnose_ticket_fields(ticket_url)


if __name__ == "__main__":
    asyncio.run(main())
